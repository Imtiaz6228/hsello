import { prisma } from "../lib/prisma.js";
import { ApiError } from "../middleware/error-handler.js";
const HOLD_DAYS = 3;
const withdrawalStatuses = new Set(["PENDING", "APPROVED", "REJECTED"]);
function payoutReference(prefix) {
    return `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
}
export function sellerFundsAvailableAt(from = new Date()) {
    return new Date(from.getTime() + HOLD_DAYS * 24 * 60 * 60 * 1000);
}
export async function releaseAvailableSellerEarnings(userId) {
    const where = { status: "FROZEN", availableAt: { lte: new Date() } };
    if (userId)
        where.sellerId = userId;
    const earnings = await prisma.sellerEarning.findMany({ where, select: { id: true, sellerId: true, netCents: true } });
    if (!earnings.length)
        return { releasedCount: 0, releasedCents: 0 };
    const bySeller = new Map();
    for (const earning of earnings)
        bySeller.set(earning.sellerId, (bySeller.get(earning.sellerId) ?? 0) + earning.netCents);
    await prisma.$transaction(async (tx) => {
        await tx.sellerEarning.updateMany({
            where: { id: { in: earnings.map((earning) => earning.id) }, status: "FROZEN" },
            data: { status: "AVAILABLE", releasedAt: new Date() }
        });
        for (const [sellerId, cents] of bySeller.entries()) {
            await tx.user.update({ where: { id: sellerId }, data: { balanceCents: { increment: cents } } });
        }
    });
    return { releasedCount: earnings.length, releasedCents: earnings.reduce((sum, earning) => sum + earning.netCents, 0) };
}
export async function createSellerEarningsForOrderItems(tx, items, paidAt) {
    const availableAt = sellerFundsAvailableAt(paidAt);
    for (const item of items) {
        await tx.sellerEarning.upsert({
            where: { orderItemId: item.id },
            create: {
                sellerId: item.sellerId,
                orderItemId: item.id,
                grossCents: item.totalCents,
                platformFeeCents: 0,
                netCents: item.totalCents,
                status: "FROZEN",
                availableAt
            },
            update: {}
        });
    }
}
export async function reverseSellerEarningsForOrder(orderId) {
    const earnings = await prisma.sellerEarning.findMany({
        where: { orderItem: { orderId }, status: { in: ["FROZEN", "AVAILABLE"] } },
        select: { id: true, sellerId: true, netCents: true, status: true }
    });
    if (!earnings.length)
        return;
    await prisma.$transaction(async (tx) => {
        for (const earning of earnings) {
            if (earning.status === "AVAILABLE") {
                await tx.user.update({ where: { id: earning.sellerId }, data: { balanceCents: { decrement: earning.netCents } } });
            }
            await tx.sellerEarning.update({ where: { id: earning.id }, data: { status: "REFUNDED" } });
        }
    });
}
export async function getWalletSummary(userId) {
    await releaseAvailableSellerEarnings(userId);
    const [user, frozen, pendingWithdrawals, withdrawals] = await Promise.all([
        prisma.user.findUnique({ where: { id: userId }, select: { balanceCents: true } }),
        prisma.sellerEarning.aggregate({ where: { sellerId: userId, status: "FROZEN" }, _sum: { netCents: true } }),
        prisma.withdrawalRequest.aggregate({ where: { userId, status: "PENDING" }, _sum: { amountCents: true } }),
        prisma.withdrawalRequest.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 })
    ]);
    return {
        balanceCents: user?.balanceCents ?? 0,
        availableBalanceCents: user?.balanceCents ?? 0,
        frozenSellerBalanceCents: frozen._sum.netCents ?? 0,
        pendingWithdrawalCents: pendingWithdrawals._sum.amountCents ?? 0,
        withdrawals
    };
}
export async function getSellerFinanceSummary(sellerId) {
    await releaseAvailableSellerEarnings(sellerId);
    const [wallet, frozen, availableEarnings, totalEarnings, withdrawals, todayEarnings, todayOrders] = await Promise.all([
        prisma.user.findUnique({ where: { id: sellerId }, select: { balanceCents: true } }),
        prisma.sellerEarning.aggregate({ where: { sellerId, status: "FROZEN" }, _sum: { netCents: true } }),
        prisma.sellerEarning.aggregate({ where: { sellerId, status: "AVAILABLE" }, _sum: { netCents: true } }),
        prisma.sellerEarning.aggregate({ where: { sellerId, status: { in: ["FROZEN", "AVAILABLE", "WITHDRAWN"] } }, _sum: { netCents: true }, _count: true }),
        prisma.withdrawalRequest.aggregate({ where: { userId: sellerId, status: { in: ["PENDING", "APPROVED"] } }, _sum: { amountCents: true } }),
        prisma.sellerEarning.aggregate({ where: { sellerId, createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } }, _sum: { netCents: true } }),
        prisma.sellerEarning.count({ where: { sellerId, createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } } })
    ]);
    return {
        availableBalanceCents: wallet?.balanceCents ?? 0,
        frozenBalanceCents: frozen._sum.netCents ?? 0,
        releasedSellerEarningsCents: availableEarnings._sum.netCents ?? 0,
        totalSellerEarningsCents: totalEarnings._sum.netCents ?? 0,
        totalSellerEarningCount: totalEarnings._count ?? 0,
        withdrawnCents: withdrawals._sum.amountCents ?? 0,
        todayIncomeCents: todayEarnings._sum.netCents ?? 0,
        todayOrderCount: todayOrders
    };
}
export async function createWithdrawalRequest(userId, input) {
    await releaseAvailableSellerEarnings(userId);
    const user = await prisma.user.findUnique({ where: { id: userId }, select: { balanceCents: true } });
    if (!user)
        throw new ApiError(404, "User not found.", "USER_NOT_FOUND");
    if (input.amountCents < 500)
        throw new ApiError(400, "Minimum withdrawal is $5.00.", "WITHDRAWAL_MINIMUM");
    if (user.balanceCents < input.amountCents)
        throw new ApiError(402, "Insufficient available balance for this withdrawal.", "INSUFFICIENT_FUNDS");
    const request = await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: userId }, data: { balanceCents: { decrement: input.amountCents } } });
        return tx.withdrawalRequest.create({
            data: {
                userId,
                amountCents: input.amountCents,
                blockchain: input.blockchain,
                walletAddress: input.walletAddress,
                status: "PENDING",
                providerReference: payoutReference("WD")
            }
        });
    });
    return request;
}
export async function reviewWithdrawalRequest(id, action, adminNotes) {
    const request = await prisma.withdrawalRequest.findUnique({ where: { id } });
    if (!request)
        throw new ApiError(404, "Withdrawal request not found.", "WITHDRAWAL_NOT_FOUND");
    if (request.status !== "PENDING")
        throw new ApiError(400, "Withdrawal request is not pending.", "WITHDRAWAL_NOT_PENDING");
    if (!withdrawalStatuses.has(action === "approve" ? "APPROVED" : "REJECTED"))
        throw new ApiError(400, "Invalid withdrawal status.", "WITHDRAWAL_STATUS_INVALID");
    if (action === "reject") {
        const [updated] = await prisma.$transaction([
            prisma.withdrawalRequest.update({ where: { id }, data: { status: "REJECTED", adminNotes: adminNotes ?? "Rejected by admin.", processedAt: new Date() } }),
            prisma.user.update({ where: { id: request.userId }, data: { balanceCents: { increment: request.amountCents } } })
        ]);
        return updated;
    }
    return prisma.withdrawalRequest.update({
        where: { id },
        data: { status: "APPROVED", adminNotes: adminNotes ?? "Approved by admin.", processedAt: new Date() }
    });
}
