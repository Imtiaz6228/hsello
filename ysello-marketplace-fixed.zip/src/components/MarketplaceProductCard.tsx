import {
  BadgeCheck,
  BriefcaseBusiness,
  Clock3,
  Eye,
  PackageCheck,
  PackageOpen,
  ShoppingCart,
  Star,
  Zap,
} from "lucide-react";
import { Link } from "react-router-dom";
import type { CatalogProduct } from "../data/catalog";
import { useLocale } from "../i18n/LocaleContext";

type Props = {
  product: CatalogProduct;
  onBuy: (product: CatalogProduct) => void;
  layout?: "grid" | "list";
};

export function MarketplaceProductCard({
  product,
  onBuy,
  layout = "grid",
}: Props) {
  const { formatMoney, t } = useLocale();
  const stockLabel =
    product.type === "SERVICE"
      ? "Service slot"
      : `${product.stockCount ?? 0} in stock`;
  const canPurchase =
    product.type === "SERVICE" || (product.stockCount ?? 0) > 0;
  const ProductIcon =
    product.type === "SERVICE" ? BriefcaseBusiness : PackageOpen;
  const categoryParts = product.category.split(" / ");
  const categoryLabel =
    categoryParts[categoryParts.length - 1] ?? product.category;

  return (
    <article
      className={`market-product-card ys-product-card ${layout === "list" ? "list" : ""}`}
    >
      <div className="ys-product-card-top">
        <Link
          className="ys-product-glyph"
          to={`/products/${product.slug}`}
          aria-label={`View ${product.title}`}
        >
          <ProductIcon aria-hidden="true" />
        </Link>
        <div className="ys-product-badges">
          <span className="badge green">{product.badge}</span>
          <span className="ys-product-kind">
            {product.type === "SERVICE" ? "Service" : "Digital product"}
          </span>
        </div>
      </div>
      <div className="market-product-body">
        <div className="market-product-title-row">
          <div>
            <Link
              className="market-product-category"
              to={`/categories/${product.categorySlug}`}
            >
              {categoryLabel}
            </Link>
            <Link to={`/products/${product.slug}`}>
              <h2>{product.title}</h2>
            </Link>
            <Link
              className="market-product-seller"
              to={`/stores/${product.sellerSlug}`}
            >
              {product.seller} <BadgeCheck aria-hidden="true" />
            </Link>
          </div>
        </div>
        <p>{product.description}</p>
        <div className="market-product-meta">
          <span>
            <Clock3 /> {product.afterSalesServiceHours ?? 12} hours
          </span>
          <span>
            <PackageCheck /> {stockLabel}
          </span>
          <span>
            <Star fill="currentColor" /> {product.rating || "New"}{" "}
            <small>({product.reviews})</small>
          </span>
          <span>
            <Zap /> Auto
          </span>
        </div>
        <footer>
          <div>
            <strong>{formatMoney(product.priceCents)}</strong>
            <small>Secure marketplace checkout</small>
          </div>
          <div className="market-card-actions">
            <Link to={`/products/${product.slug}`}>
              <Eye /> {t("details")}
            </Link>
            <button
              type="button"
              disabled={!canPurchase}
              onClick={() => onBuy(product)}
            >
              <ShoppingCart /> {canPurchase ? t("purchase") : "Unavailable"}
            </button>
          </div>
        </footer>
      </div>
    </article>
  );
}
